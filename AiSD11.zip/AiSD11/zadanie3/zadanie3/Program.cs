﻿using System.Text;

class Program
{
    static void Main(string[] args)
    {
        string inputFile = "In0203.txt";
        string outputFile = "Out0203.txt";

        try
        {

            string[] lines = File.ReadAllLines(inputFile);
            int n = int.Parse(lines[0].Trim());
            string t = lines[1].Trim();


            StringBuilder result = new StringBuilder();
            result.AppendLine($"n={n}, T={t}");

            char[] tExtended = ExtendText(t, n * n * n);
            int tIndex = 0;


            for (int i = 0; i < n; i++)
            {
                char[,] magicSquare = new char[n, n];
                if (i % 2 == 0)
                {

                    FillMagicSquareNormal(magicSquare, ref tIndex, tExtended);
                }
                else
                {

                    FillMagicSquareReverse(magicSquare, ref tIndex, tExtended);
                }
                result.AppendLine($"Tablica {i}");
                result.AppendLine(PrintMagicSquare(magicSquare));
            }

            File.WriteAllText(outputFile, result.ToString());
            Console.WriteLine($"Dane zapisano do pliku {outputFile}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Wystąpił błąd: {ex.Message}");
        }
    }

    static char[] ExtendText(string t, int length)
    {
        char[] extended = new char[length];
        for (int i = 0; i < length; i++)
        {
            extended[i] = t[i % t.Length];
        }
        return extended;
    }

    static void FillMagicSquareNormal(char[,] square, ref int tIndex, char[] tExtended)
    {
        int n = square.GetLength(0);
        int layers = (n + 1) / 2;

        for (int layer = 0; layer < layers; layer++)
        {

            for (int col = layer; col < n - layer; col++)
            {
                square[layer, col] = tExtended[tIndex++];
            }

            for (int row = layer + 1; row < n - layer; row++)
            {
                square[row, n - layer - 1] = tExtended[tIndex++];
            }

            for (int col = n - layer - 2; col >= layer; col--)
            {
                square[n - layer - 1, col] = tExtended[tIndex++];
            }

            for (int row = n - layer - 2; row > layer; row--)
            {
                square[row, layer] = tExtended[tIndex++];
            }
        }
    }

    static void FillMagicSquareReverse(char[,] square, ref int tIndex, char[] tExtended)
    {
        int n = square.GetLength(0);
        int layers = (n + 1) / 2;

        for (int layer = layers - 1; layer >= 0; layer--)
        {

            for (int col = layer; col < n - layer; col++)
            {
                square[layer, col] = tExtended[tIndex++];
            }

            for (int row = layer + 1; row < n - layer; row++)
            {
                square[row, n - layer - 1] = tExtended[tIndex++];
            }

            for (int col = n - layer - 2; col >= layer; col--)
            {
                square[n - layer - 1, col] = tExtended[tIndex++];
            }

            for (int row = n - layer - 2; row > layer; row--)
            {
                square[row, layer] = tExtended[tIndex++];
            }
        }
    }

    static string PrintMagicSquare(char[,] square)
    {
        int n = square.GetLength(0);
        StringBuilder sb = new StringBuilder();
        for (int row = 0; row < n; row++)
        {
            sb.Append("[");
            for (int col = 0; col < n; col++)
            {
                sb.Append(square[row, col]);
                if (col < n - 1) sb.Append(", ");
            }
            sb.AppendLine("]");
        }
        return sb.ToString();
    }
}

